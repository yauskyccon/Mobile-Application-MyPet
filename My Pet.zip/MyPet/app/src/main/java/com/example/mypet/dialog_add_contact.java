package com.example.mypet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class dialog_add_contact extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog_add_contact);
    }
}