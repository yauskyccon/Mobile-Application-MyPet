package com.example.mypet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class feeding_card extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feeding_card);
    }
}