package com.example.mypet;

public interface ItemClickListener {

    void onClick(String s);
}
